﻿using System;

public class Hero : Mob
{
    public Hero(int hp, int attack) : base(hp,attack)
    {
    }

    public bool IsHpMoreThen75()
    {
        if (HP > 73) return true;
        return false;
    }

    public override string ToString()
    {
        return $"Mario with HP = {HP} and attack = {HP}";
    }
}

