﻿using System;

class Kikstarter
{
    // Данный тип необходимо обязательно использовать
    public delegate int GetMoneyDelegate();

    GetMoneyDelegate[] getMoney;
    private int m;

    public Kikstarter(int m, Hipster[] hipsters)
    {
        this.m = m;
        getMoney = new GetMoneyDelegate[hipsters.Length];
        int temp =0;
        foreach (var hip in hipsters)
        {
            temp += hip.money;
        }

        if (temp < m)
            throw new InvalidOperationException("Not enough money");

    }

    public int Run()
    {
        if (getMoney.Length == 0) throw new ArgumentException("Not enough hipsters");
        int c=0;
        do
        {
            foreach (var hip in getMoney)
            {
                m -= hip();
            }

            c++;
        } while (m > 0);

        return c;
    }
}