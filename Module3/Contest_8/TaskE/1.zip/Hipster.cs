﻿using System;

internal class Hipster
{
    private int money;
    private int donate;

    public Hipster(int money, int donate)
    {
        this.money = money;
        this.donate = donate;
    }
    
    public int Money { get=>money; }

    public int GetMoney()
    {
        if (money > donate)
        {
            money -= donate;
            return donate;
        }

        return 0;

    }
}