﻿using System;

class Kikstarter
{
    // Данный тип необходимо обязательно использовать
    public delegate int GetMoneyDelegate();

    GetMoneyDelegate[] getMoney;
    private int m;

    public Kikstarter(int m, Hipster[] hipsters)
    {
        this.m = m;
        if (hipsters.Length == 0) throw new ArgumentException("Not enough hipsters");
        int checkAllMoney = 0;
        foreach (var hip in hipsters)
        {
            checkAllMoney += hip.Money;
        }

        if (checkAllMoney < m)
            throw new InvalidOperationException("Not enough money");
        
        getMoney = new GetMoneyDelegate[hipsters.Length];

        for (int i = 0; i < getMoney.Length; i++)
        {
            var i1 = i;
            getMoney[i] = () => hipsters[i1].GetMoney();
        }
    }

    public int Run()
    {

        int counter = 0;
        do
        {
            foreach (var income in getMoney)
            {
                m -= income();
            }

            counter++;
        } while (m > 0);

        return counter;

    }
}