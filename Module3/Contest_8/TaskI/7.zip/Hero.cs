﻿using System;

public class Hero : Mob
{
    private int initialHP;
    public Hero(int hp, int attack) : base(hp,attack)
    {
        initialHP = hp;
    }

    public bool IsHpMoreThen75()
    {
        if (HP >= 75*initialHP/100) return true;
        return false;
    }

    public override string ToString()
    {
        return $"Mario with HP = {HP} and attack = {Attack}";
    }
}

