﻿using System;
using System.IO;

class Program
{
    public static void Main(string[] args)
    {
        using (var reader = new StreamReader(File.Open("input.txt", FileMode.Open)))
        {
            ushort n = ushort.Parse(reader.ReadLine() ?? string.Empty);
            ushort[] arr = new ushort[n];
            for (int i = 0; i < n; i++)
            {
                arr[i] = ushort.Parse(reader.ReadLine() ?? string.Empty);
            }

            using (var binWriter = new BinaryWriter(File.Open("output.bin", FileMode.OpenOrCreate)))
            {
                binWriter.Write(Convert.ToString(n, 2));
                foreach (var number in arr)
                {
                    binWriter.Write(Convert.ToString(number, 2));
                }
            }
        }
    }
}