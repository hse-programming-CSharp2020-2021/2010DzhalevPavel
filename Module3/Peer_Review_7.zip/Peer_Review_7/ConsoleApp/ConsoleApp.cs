﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Globalization;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using ManageTasks;
using System.Reflection;
using System.Xml.Linq;
using Newtonsoft.Json;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace ConsoleApp
{
    static class Program
    {
        public static List<Project> _projects = new List<Project>();
        private static List<User> _users = new List<User>();


        static void Main(string[] args)
        {
            // Welcome message.
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Welcome to my Task Manager Console App!\n" +
                              "If you ever feel lost, type help to view all available commands");
            
            // Checks for previously saved data and fills _projects and _users if it is available.
            RetrieveData();

            // A try-catch which enables the program to only close if the Esc key is pressed.
            try
            {
                string input = string.Empty;
                do
                {
                    do
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.Write("Manage tasks: ");
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        input = Console.ReadLine();
                        HandleCommands(input);
                    } while (Exit(input));

                    Console.WriteLine($"Press Esc to exit and any other key to continue...");
                } while (Console.ReadKey().Key != ConsoleKey.Escape);
            }
            // Catches all exceptions
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        private static void AddTask()
        {
            Console.Write("Task type (epic, story, task, bug): ");
            string type = Console.ReadLine();

            if (type.Split(" ").Length == 1)
            {
                // TODO: Implement task logic here.
                switch (type)
                {
                    case "epic":
                        break;
                    case "story":
                        break;
                    case "task":
                        break;
                    case "bug":
                        break;
                    default:
                        Console.WriteLine("You have entered a wrong type. Please check spelling.");
                        break;
                }
            }else Console.WriteLine("You have entered a wrong type. Please check spelling.");
        }

        /// <summary>
        /// Adds a user to the list of _users.
        /// </summary>
        /// <param name="name"></param>
        public static void AddUser()
        {
            Console.Write("Name of new user: ");
            string name = Console.ReadLine();
            try
            {
                if (name == "")
                    throw new ArgumentException("User name is not valid.");
                _users.Add(new User(name));
            }
            catch (Exception e)
            {
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine($"Unsuccessful user creation. Error: {e.Message}");
                Console.ForegroundColor = ConsoleColor.Yellow;
            }
        }

        /// <summary>
        /// Displays all currently available _users.
        /// </summary>
        public static void DisplayUsers()
        {
            if (_users.Count == 0)
                Console.WriteLine("You haven't added any users yet.");
            else
            {
                foreach (var user in _users)
                {
                    Console.WriteLine(user);
                }
            }
        }

        /// <summary>
        /// Add a new project with no tasks.
        /// </summary>
        public static void CreateProject()
        {
            Console.Write("Enter project name: ");
            string name = Console.ReadLine();

            if (name == "")
            {
                Console.WriteLine("Project name cannot be empty.");
                CreateProject();
            }
            else
            {
                _projects.Add(new Project(name));
                Console.WriteLine($"Congratulations! You have successfully added a project named {name}.");
            }
        }

        /// <summary>
        /// Displays all _projects.
        /// </summary>
        public static void DisplayProjects()
        {
            if (_projects.Count == 0)
            {
                Console.WriteLine("You have not added any projects yet.");
            }
            else
            {
                foreach (var project in _projects)
                {
                    Console.WriteLine(project);
                }
            }
        }

        /// <summary>
        /// Changes the name of the selected project.
        /// </summary>
        /// <param name="oldName"></param>
        /// <param name="newName"></param>
        /// <exception cref="Exception"></exception>
        public static void ChangeProjectName()
        {
            Console.Write("The old name of the project: ");
            var oldName = Console.ReadLine();
            Console.Write("The new name of the project: ");
            var newName = Console.ReadLine();
            
            if (_projects.Contains(new Project(oldName)) == false)
                Console.WriteLine("This project does not exist and thus cannot be deleted.");
            _projects.Find(x => x.Name == oldName).Name = newName;
        }

        public static void HandleCommands(string input)
        {
            var cmds = input.Split(" ");

            if (input != "")
            {
                switch (cmds[0])
                {
                    case "new":
                        switch (cmds[1])
                        {
                            case "-user":
                                AddUser();
                                break;
                            case "-project":
                                CreateProject();
                                break;
                            default:
                                Console.WriteLine("Please check syntax");
                                break;
                        }

                        break;
                    case "display":
                        if (cmds.Length == 2)
                        {
                            switch (cmds[1])
                            {
                                case "-users":
                                    DisplayUsers();
                                    break;
                                case "-projects":
                                    DisplayProjects();
                                    break;
                                default:
                                    Console.WriteLine("Please check syntax");
                                    break;
                            }
                        }else Console.WriteLine("Operation does not exist. Please check spelling or view help.");
                        break;
                    case "change":
                        ChangeProjectName();
                        break;
                    case "task":
                        if (cmds.Length == 2)
                        {
                            switch (cmds[1])
                            {
                                case "new":
                                AddTask();
                                break;
                                default: 
                                Console.WriteLine("Operation does not exist. Please check spelling or view help.");
                                break;
                            }
                        }else Console.WriteLine("Operation does not exist. Please check spelling or view help.");
                        break;
                    case "help":
                        DisplayHelp();
                        break;
                    case "exit":
                        Save();
                        Exit(input);
                        break;
                    default:
                        Console.WriteLine("Functionality not implemented. Please check spelling or refer to help");
                        break;
                }
            }
            else Console.WriteLine("Command input cannot be null!");

            
        }

        /// <summary>
        /// Checks whether the app is closing or not.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public static bool Exit(string input)
        {
            if (input.Split(" ")[0] == "exit")
                return false;
            return true;
        }

        public static void DisplayHelp()
        {
            Console.WriteLine(
                $"COMMANDS\n" +
                "   new [options] \t Creates a new user, project or task. Options:\n" +
                "     -user \t\t Creates a new user\n" +
                "     -project \t\t Creates a new project\n" +
                "     -task \t\t Creates a new task\n" +
                "   display [options] \t Displays all initiated object of type options\n" +
                "     -users \t\t Displays all users\n" +
                "     -projects \t\t Displays all projects\n" +
                "   task [options] \t Operates with tasks. Options:\n" +
                "     -new \t\t Create a new task\n" +
                "   change \t\t Changes the name of a previously created project\n" +
                "   help \t\t Displays all available functions\n" +
                "   exit \t\t Exits the program");
        }

        
        /// <summary>
        /// Saves all the data before closing the app.
        /// </summary>
        public static void Save()
        {
            string userJson = JsonSerializer.Serialize(_users);
            File.WriteAllText("users.json", userJson);
            
            string projectJson = JsonSerializer.Serialize(_projects);
            File.WriteAllText("projects.json", projectJson);

        }

        /// <summary>
        /// Retrieves the data from previous builds.
        /// </summary>
        public static void RetrieveData()
        {
            string userJson = File.ReadAllText("users.json");
            _users = JsonConvert.DeserializeObject<List<User>>(userJson);
            
            string projectJson = File.ReadAllText("projects.json");
            _projects = JsonConvert.DeserializeObject<List<Project>>(projectJson);
            
        }
    }
}