using System;
using System.Collections.Generic;

public class TeamLead : Programmer
{
    private readonly List<Programmer> programmers;

    public TeamLead(int id, List<Programmer> programmers) : base(id)
    {
        this.programmers = programmers;
    }

    public List<Programmer> Programmers => programmers;

    public void HuntProgrammers(List<TeamLead> teamLeads)
    {
        foreach (var teamLead in teamLeads)
        {
            foreach (var programmer in teamLead.programmers)
            {
                if (programmer.LinesOfCode % (Id+1) == 0)
                {
                    teamLead.programmers.Remove(programmer);
                    programmers.Add(programmer);
                    break;
                }
            }
        }   
    }

    public int GetWrittenLinesOfCode()
    {
        int sum = 0;
        foreach (var programmer in programmers)
        {
            sum += programmer.LinesOfCode;
        }

        return sum;
    }

    public override string ToString()
    {
        return String.Format("Team lead #{0}\nAmount of programmers in team: {1}", Id, programmers.Count);
    }
}