﻿using System;
using System.Collections;

public class Worker
{
    private Apple[] apples;

    public Worker(Apple[] apples)
    {
        this.apples = apples;
    }

    public Apple[] GetSortedApples()
    {
        int j = 0;
        Apple[] sortedApples = new Apple[apples.Length];
        for (int i = 0; i < apples.Length; i++)
        {
            sortedApples[i] = apples[i];
        }
        Array.Sort(sortedApples, new ApplesComparer());
        
        return sortedApples;
    }

    class ApplesComparer : IComparer
    {
        public int Compare(object a, object b)
        {
            return (new CaseInsensitiveComparer()).Compare(((Apple)a).Weight, ((Apple)b).Weight);
        }
    }
}
