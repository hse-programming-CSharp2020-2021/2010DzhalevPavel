﻿
using System;
using System.Globalization;

public class Sheep
{
    private int id;
    private string name;
    private string sound;

    public int Id
    {
        get => id;
        set
        {
            if(id<=0||id>999)
                throw new ArgumentException("Incorrect input");
            id = value;
        }
    }

    public string Name
    {
        get => name;
        set => name = value;
    }

    public string Sound
    {
        get => sound;
        set => sound = value;
    }

    public Sheep(int id, string name, string sound)
    {
        this.id = id;
        this.name = name;
        this.sound = sound;
    }

    public override string ToString()
    {
        return $"[{id}-{name}]: {sound}...{sound}";
    }
}
