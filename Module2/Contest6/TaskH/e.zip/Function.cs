﻿using System;
using System.Diagnostics.CodeAnalysis;

public abstract class Function
{
    public static Function GetFunction(string functionName)
    {
        if(functionName!="Sin"&&functionName!="Exp"&&functionName!="Parabola")
            throw new ArgumentException("Incorrect input");
        return functionName switch
        {
            "Sin" => new Sin(),
            "Exp" => new Exponent(),
            "Parabola" => new Parabola(),
            _ => null
        };
    }

    public abstract double GetValueInX(double x);

    public static double SolveIntegral(Function func, double left, double right, double step)
    {
        double integral=0;
        if(right<left)
            throw new ArgumentException("Left border greater than right");
        if(double.IsNaN(func.GetValueInX(left))||double.IsNaN(func.GetValueInX(right)))
            throw new ArgumentException("Function is not defined in point");
        for (double i = left; i < right-step; i += step)
        {
            integral += (func.GetValueInX(i) + func.GetValueInX(i + step)) * step / 2;
        }

        return integral;
    }
}
