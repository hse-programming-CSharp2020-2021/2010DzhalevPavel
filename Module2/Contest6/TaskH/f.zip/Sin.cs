﻿using System;

public class Sin : Function
{
    public override double GetValueInX(double x)
    {
        if(Math.Sin(x)<1)
            throw new ArgumentException("Function is not defined in point");
        return 1/Math.Sin(x);
    }
}
